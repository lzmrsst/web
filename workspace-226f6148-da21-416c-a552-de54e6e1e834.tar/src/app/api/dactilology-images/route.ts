import { NextRequest, NextResponse } from 'next/server';

// En una implementación real, usarías una base de datos para almacenar las imágenes
// Por ahora, usaremos un almacenamiento en memoria para demostración
const imageStorage = new Map<string, string>();

export async function POST(request: NextRequest) {
  try {
    const { letter, imageData } = await request.json();
    
    if (!letter || !imageData) {
      return NextResponse.json(
        { error: 'Se requieren letra e imagen' },
        { status: 400 }
      );
    }

    if (!/^[a-zA-Z]$/.test(letter)) {
      return NextResponse.json(
        { error: 'La letra debe ser un carácter alfabético' },
        { status: 400 }
      );
    }

    // Guardar la imagen
    imageStorage.set(letter.toLowerCase(), imageData);

    return NextResponse.json({ 
      success: true, 
      message: `Imagen para la letra ${letter.toUpperCase()} guardada exitosamente` 
    });
  } catch (error) {
    console.error('Error al guardar la imagen:', error);
    return NextResponse.json(
      { error: 'Error al guardar la imagen' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const letter = searchParams.get('letter');

    if (letter) {
      // Obtener imagen específica
      if (!/^[a-zA-Z]$/.test(letter)) {
        return NextResponse.json(
          { error: 'La letra debe ser un carácter alfabético' },
          { status: 400 }
        );
      }

      const imageData = imageStorage.get(letter.toLowerCase());
      if (!imageData) {
        return NextResponse.json(
          { error: 'Imagen no encontrada' },
          { status: 404 }
        );
      }

      return NextResponse.json({ letter: letter.toUpperCase(), imageData });
    } else {
      // Obtener todas las imágenes
      const allImages = Object.fromEntries(imageStorage);
      return NextResponse.json({ images: allImages });
    }
  } catch (error) {
    console.error('Error al obtener las imágenes:', error);
    return NextResponse.json(
      { error: 'Error al obtener las imágenes' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const letter = searchParams.get('letter');

    if (!letter) {
      return NextResponse.json(
        { error: 'Se requiere la letra a eliminar' },
        { status: 400 }
      );
    }

    if (!/^[a-zA-Z]$/.test(letter)) {
      return NextResponse.json(
        { error: 'La letra debe ser un carácter alfabético' },
        { status: 400 }
      );
    }

    const deleted = imageStorage.delete(letter.toLowerCase());
    if (!deleted) {
      return NextResponse.json(
        { error: 'Imagen no encontrada' },
        { status: 404 }
      );
    }

    return NextResponse.json({ 
      success: true, 
      message: `Imagen para la letra ${letter.toUpperCase()} eliminada exitosamente` 
    });
  } catch (error) {
    console.error('Error al eliminar la imagen:', error);
    return NextResponse.json(
      { error: 'Error al eliminar la imagen' },
      { status: 500 }
    );
  }
}