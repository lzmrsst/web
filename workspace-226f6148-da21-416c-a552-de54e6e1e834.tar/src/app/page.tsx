"use client";

import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Download, Upload, Type, Trash2 } from "lucide-react";

export default function Home() {
  const [inputText, setInputText] = useState("");
  const [imageSize, setImageSize] = useState("50");
  const [dactilologyImages, setDactilologyImages] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Cargar imágenes guardadas al iniciar
  useEffect(() => {
    const loadSavedImages = async () => {
      try {
        const response = await fetch('/api/dactilology-images');
        if (response.ok) {
          const data = await response.json();
          setDactilologyImages(data.images || {});
        }
      } catch (error) {
        console.error('Error al cargar imágenes guardadas:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadSavedImages();
  }, []);

  // Mapeo de letras a representaciones dactilológicas (por ahora usando placeholders)
  const getDactilologyImage = (letter: string) => {
    if (dactilologyImages[letter.toLowerCase()]) {
      return dactilologyImages[letter.toLowerCase()];
    }
    // Placeholder con la letra como fallback
    return `data:image/svg+xml;base64,${btoa(`
      <svg width="200" height="200" xmlns="http://www.w3.org/2000/svg">
        <rect width="200" height="200" fill="#f3f4f6" stroke="#d1d5db" stroke-width="2" rx="10"/>
        <text x="100" y="120" font-family="Arial, sans-serif" font-size="80" font-weight="bold" text-anchor="middle" fill="#374151">${letter.toUpperCase()}</text>
        <text x="100" y="160" font-family="Arial, sans-serif" font-size="16" text-anchor="middle" fill="#6b7280">Dactilología</text>
      </svg>
    `)}`;
  };

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>, letter: string) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const result = e.target?.result as string;
        
        // Actualizar estado local
        setDactilologyImages(prev => ({
          ...prev,
          [letter.toLowerCase()]: result
        }));

        // Guardar en el servidor
        try {
          const response = await fetch('/api/dactilology-images', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              letter: letter.toLowerCase(),
              imageData: result
            }),
          });

          if (!response.ok) {
            console.error('Error al guardar la imagen en el servidor');
          }
        } catch (error) {
          console.error('Error al conectar con el servidor:', error);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const downloadTranslation = async () => {
    if (!inputText.trim()) return;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = parseInt(imageSize) / 100;
    const letterWidth = 200 * size;
    const letterHeight = 200 * size;
    const padding = 20;
    
    canvas.width = (inputText.length * letterWidth) + (padding * 2);
    canvas.height = letterHeight + (padding * 2);

    // Fondo blanco
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Cargar todas las imágenes primero
    const letters = inputText.split('').filter(letter => letter.match(/[a-zA-Z]/));
    const imagePromises = letters.map(letter => {
      return new Promise<HTMLImageElement>((resolve) => {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => resolve(img);
        img.src = getDactilologyImage(letter);
      });
    });

    try {
      const images = await Promise.all(imagePromises);
      
      // Dibujar cada letra
      let imageIndex = 0;
      inputText.split('').forEach((letter, index) => {
        if (letter.match(/[a-zA-Z]/)) {
          ctx.drawImage(
            images[imageIndex], 
            padding + (index * letterWidth), 
            padding, 
            letterWidth, 
            letterHeight
          );
          imageIndex++;
        }
      });

      // Descargar la imagen
      const link = document.createElement('a');
      link.download = `dactilologia_${inputText.replace(/[^a-zA-Z]/g, '_')}.png`;
      link.href = canvas.toDataURL();
      link.click();
    } catch (error) {
      console.error('Error al generar la imagen:', error);
      alert('Error al generar la imagen de descarga. Por favor, intenta nuevamente.');
    }
  };

  const triggerFileInput = (letter: string) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => handleImageUpload(e as any, letter);
    input.click();
  };

  const deleteCustomImage = async (letter: string) => {
    try {
      const response = await fetch(`/api/dactilology-images?letter=${letter.toLowerCase()}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        setDactilologyImages(prev => {
          const newImages = { ...prev };
          delete newImages[letter.toLowerCase()];
          return newImages;
        });
      } else {
        console.error('Error al eliminar la imagen del servidor');
      }
    } catch (error) {
      console.error('Error al conectar con el servidor:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">Traductor Dactilológico</h1>
          <p className="text-gray-600">Traduce texto español a alfabeto dactilológico</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Panel de entrada */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Type className="w-5 h-5" />
                Texto de entrada
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder="Ingresa el texto en español..."
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                className="min-h-[120px]"
              />
              
              <div className="space-y-2">
                <Label>Tamaño de las imágenes</Label>
                <Select value={imageSize} onValueChange={setImageSize}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="25">25%</SelectItem>
                    <SelectItem value="50">50%</SelectItem>
                    <SelectItem value="75">75%</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button 
                onClick={downloadTranslation}
                disabled={!inputText.trim()}
                className="w-full"
              >
                <Download className="w-4 h-4 mr-2" />
                Descargar traducción
              </Button>
            </CardContent>
          </Card>

          {/* Panel de visualización */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Traducción Dactilológica</CardTitle>
            </CardHeader>
            <CardContent>
              {inputText ? (
                <div className="flex flex-wrap gap-4 justify-center">
                  {inputText.split('').map((letter, index) => {
                    if (letter.match(/[a-zA-Z]/)) {
                      const size = parseInt(imageSize) / 100;
                      return (
                        <div key={index} className="flex flex-col items-center gap-2">
                          <img
                            src={getDactilologyImage(letter)}
                            alt={`Dactilología ${letter.toUpperCase()}`}
                            style={{ 
                              width: `${200 * size}px`, 
                              height: `${200 * size}px`,
                              objectFit: 'contain'
                            }}
                            className="border rounded-lg bg-white shadow-sm"
                          />
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => triggerFileInput(letter)}
                          >
                            <Upload className="w-3 h-3 mr-1" />
                            {letter.toUpperCase()}
                          </Button>
                        </div>
                      );
                    } else if (letter === ' ') {
                      return <div key={index} className="w-8" />;
                    }
                    return null;
                  })}
                </div>
              ) : (
                <div className="text-center text-gray-500 py-12">
                  <Type className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Ingresa texto para ver la traducción dactilológica</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Panel de gestión de imágenes */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Gestionar Imágenes Dactilológicas</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-4">
              Haz clic en los botones de las letras arriba para cargar tus propias imágenes dactilológicas. 
              Las imágenes deben ser cuadradas para una mejor visualización.
            </p>
            {isLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
                <p className="text-gray-600">Cargando imágenes guardadas...</p>
              </div>
            ) : (
              <div className="grid grid-cols-6 md:grid-cols-8 lg:grid-cols-13 gap-2">
                {'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map((letter) => (
                  <div key={letter} className="flex flex-col items-center gap-1">
                    <div className="w-12 h-12 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center bg-gray-50 relative">
                      {dactilologyImages[letter.toLowerCase()] ? (
                        <>
                          <img
                            src={dactilologyImages[letter.toLowerCase()]}
                            alt={letter}
                            className="w-full h-full object-cover rounded"
                          />
                          <button
                            onClick={() => deleteCustomImage(letter)}
                            className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center hover:bg-red-600 transition-colors"
                            title="Eliminar imagen"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </>
                      ) : (
                        <span className="text-lg font-semibold text-gray-400">{letter}</span>
                      )}
                    </div>
                    <span className="text-xs text-gray-500">{letter}</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}